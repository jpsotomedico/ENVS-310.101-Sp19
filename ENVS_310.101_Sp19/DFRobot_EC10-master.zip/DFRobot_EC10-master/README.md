# DFRobot_EC10
Arduino library for Gravity: Analog Electrical Conductivity Sensor / Meter Kit (K=10), SKU: DFR0300-H
